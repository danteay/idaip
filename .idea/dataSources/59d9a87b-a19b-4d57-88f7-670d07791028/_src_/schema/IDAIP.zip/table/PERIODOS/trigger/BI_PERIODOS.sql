CREATE TRIGGER BI_PERIODOS
BEFORE INSERT
  ON PERIODOS
FOR EACH ROW
  begin   
  if :NEW."PERIODO_ID" is null then 
    select "PERIODOS_SEQ".nextval into :NEW."PERIODO_ID" from sys.dual; 
  end if; 
end;
/
