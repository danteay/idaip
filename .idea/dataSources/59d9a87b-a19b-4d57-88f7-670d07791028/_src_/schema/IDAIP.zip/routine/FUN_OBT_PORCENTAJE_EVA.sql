CREATE function fun_obt_porcentaje_Eva(pEvaluacion_Id Number) return integer is

  nResultado Number := 0;
begin

   Select Round(avg(Porcentaje)) Into nResultado From
   (
   Select fun_obt_porcentaje(ef.articulo_fraccion_id, ef.respuesta) Porcentaje
      from EVALUACIONES_FRACCIONES ef
    Where Evaluacion_id = pEvaluacion_Id
    );


  Return nResultado;

end fun_obt_porcentaje_Eva;
/
