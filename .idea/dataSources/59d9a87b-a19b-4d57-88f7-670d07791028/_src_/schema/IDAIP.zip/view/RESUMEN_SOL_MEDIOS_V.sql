CREATE VIEW RESUMEN_SOL_MEDIOS_V AS select m.Descripcion, Count(1) Solicitudes
   from solicitudes_informacion s, Medios_Solicitud m
  Where s.Medio_Solicitud_Id = m.Medio_Solicitud_Id
Group by m.descripcion
/
