CREATE TRIGGER BI_INCIDENCIAS
BEFORE INSERT
  ON INCIDENCIAS
FOR EACH ROW
  begin   
  if :NEW."INCIDENCIA_ID" is null then 
    select "INCIDENCIAS_SEQ_".nextval into :NEW."INCIDENCIA_ID" from sys.dual; 
  end if; 
end;
/
