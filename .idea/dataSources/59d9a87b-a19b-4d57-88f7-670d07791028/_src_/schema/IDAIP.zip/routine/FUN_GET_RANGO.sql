CREATE function "FUN_GET_RANGO"
(ppromedio in NUMBER)
return VARCHAR2
is
begin
Begin
  Return 'Hola';
End;
end;
/
