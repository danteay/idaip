CREATE TRIGGER BI_EVALUACIONES
BEFORE INSERT
  ON EVALUACIONES
FOR EACH ROW
  begin   
  if :NEW."EVALUACION_ID" is null then 
    select "EVALUACIONES_SEQ".nextval into :NEW."EVALUACION_ID" from sys.dual; 
  end if; 
  
  
end;
/
