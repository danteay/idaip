CREATE VIEW MAS_SOLITUDES_V AS select sujeto, solicitudes from
(
select sujeto, solicitudes, rownum myrow from
(
select so.sujeto, Count(1) solicitudes
        from solicitudes_informacion si,
              sujetos_obligados so
  where si.sujeto_obligado_id = so.sujeto_obligado_id
 Group by so.sujeto
 order by 2 desc
 )
 )
 where myrow <= 7
/
