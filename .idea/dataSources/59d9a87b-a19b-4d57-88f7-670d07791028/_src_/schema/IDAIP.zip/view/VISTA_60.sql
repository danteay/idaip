CREATE VIEW VISTA_60 AS (select count(*) total_60 from evaluaciones where (resultado between 60 and 85) and periodo_id=61 and tipo_evaluacion=1 and cierre=1)
/
