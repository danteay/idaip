CREATE function fun_obt_porcentaje(pArticulo_Fraccion_Id Number,
                                              pValor Number) return integer is
  
  nMax Number := 0;
  nResultado Number := 0;
begin
  Select Max(valor) Into nMax From Art_Fracc_Respuestas
     Where Articulo_Fraccion_Id = pArticulo_Fraccion_Id;
     
  nResultado := Trunc((pValor*100) / nMax);   
  
  Return nResultado;
 
end fun_obt_porcentaje;
/
