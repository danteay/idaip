CREATE VIEW VISTA_0 AS (select count(*) total_0 from evaluaciones where (resultado between 0 and 60) and periodo_id=61 and tipo_evaluacion=1 and cierre=1)
/
