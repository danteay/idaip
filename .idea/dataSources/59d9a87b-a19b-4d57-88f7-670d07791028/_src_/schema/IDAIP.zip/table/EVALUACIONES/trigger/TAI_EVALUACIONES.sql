CREATE TRIGGER TAI_EVALUACIONES
AFTER INSERT
  ON EVALUACIONES
FOR EACH ROW
  begin

  If :New.sujeto_obligado_id Is Not Null Then
    pgk_idaip.pro_crear_encuesta(:NEW.EVALUACION_ID,
                                 :New.sujeto_obligado_id);
  End If;
end;
/
