CREATE TRIGGER BI_ART_FRACC_RESPUESTAS
BEFORE INSERT
  ON ART_FRACC_RESPUESTAS
FOR EACH ROW
  begin   
  if :NEW."ART_FRACC_RESPUESTA_ID" is null then 
    select "ART_FRACC_RESPUESTAS_SEQ".nextval into :NEW."ART_FRACC_RESPUESTA_ID" from sys.dual; 
  end if; 
  
  If :New.Valor  Is Null Then
    :New.Valor  := 1;
  End If;
  
  If :New.Estatus Is Null Then
    :New.Estatus := 1;
  End If;
  
end;
/
