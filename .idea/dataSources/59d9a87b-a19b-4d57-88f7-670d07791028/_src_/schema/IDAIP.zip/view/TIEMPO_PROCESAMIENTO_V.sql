CREATE VIEW TIEMPO_PROCESAMIENTO_V AS Select Tipo_Sujeto, Round(Avg(Dias)) Dias
  From (
select ts.Descripcion Tipo_Sujeto,
       si.Fecha_Atencion - si.Fecha_Solicitud Dias
        from solicitudes_informacion si,
              sujetos_obligados so, tipos_sujetos_obligados ts
  where si.sujeto_obligado_id = so.sujeto_obligado_id
    And so.Tipo_Sujeto_Obligado_Id = ts.Tipo_Sujeto_Obligado_Id
    )
  Group by Tipo_Sujeto
/
