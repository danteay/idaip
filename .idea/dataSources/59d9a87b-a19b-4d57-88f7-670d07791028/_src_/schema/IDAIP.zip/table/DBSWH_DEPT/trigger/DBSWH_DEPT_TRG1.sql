CREATE TRIGGER DBSWH_DEPT_TRG1
BEFORE INSERT
  ON DBSWH_DEPT
FOR EACH ROW
  begin
    if :new.deptno is null then
        select DBSWH_DEPT_SEQ.nextval into :new.deptno from dual;
   end if;
end;
/
