CREATE VIEW EVALUACIONES_SUJETOS_V AS select so.sujeto_obligado_id id,so.tipo_sujeto_obligado_id tipo,so.sujeto,
       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 244) "A",
       (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 244) "A_",
       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 245) "B",
      (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 245) "B_",
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 246) "C",
       (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 246) "C_",
       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 247) "D",
        (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 247) "D_",
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 248) Mayo,
        (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 248) "E_",
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 249) Junio,
          (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 249) "F_",
           0 "G_", 0 "H_", 0 "I_", 0 "J_",
         (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 181) Julio,
          (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 201) Agosto,
           (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 221) Septiembre,
          (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 241) Octubre,
         (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 242) Noviembre,
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 251) Diciembre,

        (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 242) Noviembre_Id,

        (Select e.evaluacion_id From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 251) Diciembre_Id,


        (Select round(sum(e.Resultado),0) From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id In (244, 245, 246, 247, 248, 249, 251) )"T",
        so.portal_internet portal
         from sujetos_obligados so
/
