CREATE VIEW RESUMEN_EVA_V AS select resumen_eva_id, so.sujeto sujeto_obligado,
       a1, a2, a3, a4,
       ((a1 + a2 + a3 + a4) / 4) Promedio,
        a1 || '%' a1p,
        a2 || '%' a2p,
        a3 || '%' a3p,
        a4 || '%' a4p,
       ((a1 + a2 + a3 + a4) / 4) || '%' Promediop,
       so.portal_internet,
        annio,
       tso.descripcion Tipo_Sujeto
from resumen_eva t, sujetos_obligados so, tipos_sujetos_obligados tso
  where t.sujeto_obligado_id = so.sujeto_obligado_id
    And so.Tipo_Sujeto_Obligado_Id = tso.Tipo_Sujeto_Obligado_Id
/
