CREATE VIEW TEMP_1 AS select so.sujeto_obligado_id id,so.tipo_sujeto_obligado_id tipo,so.sujeto,
       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 61) "A",

       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 81) "B",

        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 101) "C",

       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 121) "D",
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 141) Mayo,

        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 161) Junio,
         (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 181) Julio,
          (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 201) Agosto,
           (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 221) Septiembre,
          (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 241) Octubre,
         (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 242) Noviembre,
        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 243) Diciembre,
        (Select round(sum(e.Resultado),0) From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id In (61,81,101,121, 141, 161, 181, 201,221, 241, 242, 243) )"T",


        so.portal_internet portal
         from sujetos_obligados so
/
