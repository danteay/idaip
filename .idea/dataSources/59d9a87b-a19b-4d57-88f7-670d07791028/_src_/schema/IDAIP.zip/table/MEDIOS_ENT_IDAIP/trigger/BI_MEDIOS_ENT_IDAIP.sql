CREATE TRIGGER BI_MEDIOS_ENT_IDAIP
BEFORE INSERT
  ON MEDIOS_ENT_IDAIP
FOR EACH ROW
  begin   
  if :NEW."MEDIO_ENT_IDAIP_ID" is null then 
    select "MEDIOS_ENT_IDAIP_SEQ".nextval into :NEW."MEDIO_ENT_IDAIP_ID" from sys.dual; 
  end if; 
end;
/
