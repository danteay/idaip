CREATE TRIGGER TBI_ROLES_SISTEMA
BEFORE INSERT
  ON ROLES_SISTEMA
FOR EACH ROW
  declare
  tmpSeq Number(9) := 0;
begin
  If :New.Rol_Sistema_Id Is Null Then
    Select Seq_rol_sistema_id.Nextval Into tmpseq From Dual;
    :New.Rol_Sistema_Id  := tmpseq;
  End If;

end TBI_Roles_Sistema;
/
