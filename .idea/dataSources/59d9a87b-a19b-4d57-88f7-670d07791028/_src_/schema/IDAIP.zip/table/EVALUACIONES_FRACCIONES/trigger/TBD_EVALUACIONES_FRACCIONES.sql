CREATE TRIGGER TBD_EVALUACIONES_FRACCIONES
BEFORE DELETE
  ON EVALUACIONES_FRACCIONES
FOR EACH ROW
  begin
  Delete DET_EVAL_FRACCIONES
    Where evaluacion_fraccion_id  = :Old.evaluacion_fraccion_id ;


end;
/
