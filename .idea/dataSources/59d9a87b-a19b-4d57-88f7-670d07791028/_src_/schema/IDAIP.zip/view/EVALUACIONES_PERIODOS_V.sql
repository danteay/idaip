CREATE VIEW EVALUACIONES_PERIODOS_V AS select so.sujeto,
       (Select e.Resultado From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 61) "A",
       (Select round(sum(e.Resultado),0) From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And p.periodo_id  = 81) "B",

        (Select round(sum(e.Resultado),0) From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id
            And (e.periodo_id=61 or e.periodo_id=81)) "T",

        so.portal_internet portal
         from sujetos_obligados so
/
