CREATE VIEW RESUMEN_SOL_MES_V AS select  to_char(fecha_solicitud,'Month') Mes,
       Count(1) Solicitudes  from solicitudes_informacion
    Group by to_char(fecha_solicitud,'Month'),
             to_char(fecha_solicitud,'mm')
     order by to_char(fecha_solicitud,'mm')
/
